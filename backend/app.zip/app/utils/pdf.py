import fitz


def clean_text(text: str) -> str:
    text = text.replace("\x00", "")
    text = text.replace("\u0000", "")
    return text


def extract_text_from_pdf(file_path: str) -> str:
    document = fitz.open(file_path)

    pages = []

    for page in document:
        pages.append(
            clean_text(page.get_text())
        )

    document.close()

    return "\n".join(pages)


def extract_pages_from_pdf(file_path: str):
    document = fitz.open(file_path)

    pages = []

    for page_index, page in enumerate(document):
        pages.append(
            {
                "page_number": page_index + 1,
                "text": clean_text(
                    page.get_text()
                ),
            }
        )

    document.close()

    return pages


def find_chunk_bboxes(
    file_path: str,
    page_number: int,
    chunk_text: str,
):
    document = fitz.open(file_path)

    page = document.load_page(page_number - 1)

    rects = page.search_for(chunk_text)

    bboxes = [
        [r.x0, r.y0, r.x1, r.y1]
        for r in rects
    ]

    document.close()

    return bboxes